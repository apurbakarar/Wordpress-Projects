<?php
/*
 * Plugin Name: Custom Registration Form
 * Plugin URI: https://custom-registration-form.com/
 * Description: <strong>[custom-registration-form]</strong> Use this shortcode in your pages to visible the form.
 * Author: Apurba Karar
 * Author URI: https://profile.apurbakarar.com/
 * Version: 1.0
 * Requires at least: 6.2
 * Requires PHP: 7.4
 */

 if(!defined('ABSPATH')) exit();

define('CRF_DIR', plugin_dir_path(__FILE__));
define('CRF_INCLUDES_DIR', trailingslashit(CRF_DIR . 'includes'));
define('CRF_TEXT_DOMAIN', 'customer-registration-form');

 // LOAD HEADER ASSETS
 add_action('wp_head', 'load_header_assets_files');
 function load_header_assets_files(){
	wp_enqueue_style('custom_reg_bootstrap_min_css', 'https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css');

	wp_register_style( 'custom_reg_custom_css', plugins_url( '/assets/custom-registration-form.css' , __FILE__ ) );
	wp_enqueue_style( 'custom_reg_custom_css' );
 }


 // LOAD FOOTER ASSETS
 add_action('wp_footer', 'load_footer_assets_files');
 function load_footer_assets_files() {
	wp_enqueue_script('custom_reg_jquery_min_js', 'https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js');
	wp_enqueue_script('custom_reg_bootstrap_min_js', 'https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js');
	
	wp_register_script( 'custom_reg_custom_js', plugins_url( '/assets/custom-registration-form.js' , __FILE__ ) );
	wp_enqueue_script( 'custom_reg_custom_js' );
	
 }


// LOAD FORM HTML
add_shortcode('custom-registration-form', 'show_html_for_reg_form');
function show_html_for_reg_form(){

	return '<form name="custom_registration_form" data-target-url="'. plugins_url( '/ajax-handler.php' , __FILE__ ) .'">
				<div class="form-group">
				<label for="reg_name">Name:</label><span class="color-red">*</span>
				<input type="text" name="name" class="form-control" id="reg_name">
				</div>

				<div class="form-group">
				<label for="reg_email">Email:</label><span class="color-red">*</span>
				<input type="email" name="email" class="form-control" id="reg_email">
				</div>

				<div class="form-group">
				<label for="reg_mobile">Mobile:</label><span class="color-red">*</span>
				<input type="tel" name="mobile" class="form-control" id="reg_mobile" maxlength="10">
				</div>
				<div class="show-errors hide"></div>
				<button type="submit" class="btn btn-default">Submit</button>
			</form>';
}




///  ----    ADMIN SECTION

add_action('admin_menu', 'crf_create_admin_menu');
function crf_create_admin_menu(){

	add_menu_page(
		 __('Customer Registration Form'),
		 __('Customer Registration Form'),
		'manage_options',
		'customer-registration-form',
		'crf_create_admin_menu_cb', 
		'dashicons-admin-users',
		2
	);

}

function crf_create_admin_menu_cb(){

	if(file_exists(CRF_INCLUDES_DIR . 'admin-listing-page.php')) {
		require_once(CRF_INCLUDES_DIR . 'admin-listing-page.php');
	}
	else {
		exit('File not found');
	}
	

}





