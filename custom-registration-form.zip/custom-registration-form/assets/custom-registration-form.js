
$(document).ready(function(){

    $('form[name=custom_registration_form] button[type=submit]').on('click', function(e){

        e.preventDefault();
        const obj = $(this);
        const name =  $('form[name=custom_registration_form] [name=name]').val();
        const email =  $('form[name=custom_registration_form] [name=email]').val();
        const mobile =  $('form[name=custom_registration_form] [name=mobile]').val();
        const emailRegExp = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
        const mobileRegExp = /^\(?(\d{3})\)?[- ]?(\d{3})[- ]?(\d{4})$/;

        $('form[name=custom_registration_form] .show-errors').text('').addClass('hide');
        
        let error = 0;
        let errorStr = '';
        if(name == '') {
            error++; errorStr = '*Please enter your name'; $('form[name=custom_registration_form] [name=name]').focus();
        }
        else if(email == '') {
            error++; errorStr = '*Please enter your email'; $('form[name=custom_registration_form] [name=email]').focus();
        }
        else if(!email.match(emailRegExp)) {
            error++; errorStr = '*Please enter a valid email'; $('form[name=custom_registration_form] [name=email]').focus();
        }
        else if(mobile == '') {
            error++; errorStr = '*Please enter your mobile number'; $('form[name=custom_registration_form] [name=mobile]').focus();
        }
        else if(!mobileRegExp.test(mobile)) {
            error++; errorStr = '*Please enter a valid mobile number'; $('form[name=custom_registration_form] [name=mobile]').focus();
        }

        if(error != 0) {
            $('form[name=custom_registration_form] .show-errors').text(errorStr).removeClass('no-error').removeClass('hide');
        }
        else {
           
            const formData = $('form[name=custom_registration_form]').serialize();
            const ajaxUrl = $('form[name=custom_registration_form]').attr('data-target-url');
            obj.prop('disabled', true).attr('disabled', 'disabled');
            
            $.ajax({
                type: 'POST',
                url: ajaxUrl,
                data: formData,
                success: function(res){
                    if(res.trim() == 1) {
                        $('form[name=custom_registration_form]')[0].reset();
                        $('form[name=custom_registration_form] .show-errors').text('Thank you! Your registration has been successfully completed').addClass('no-error').removeClass('hide');
                        obj.prop('disabled', false).removeAttr('disabled');
                        setTimeout(() => {
                            $('form[name=custom_registration_form] .show-errors').text('').addClass('hide');
                        }, 4000);
                    }
                    else {
                        obj.prop('disabled', false).removeAttr('disabled');
                        $('form[name=custom_registration_form] .show-errors').text('Sorry! something went wrong').removeClass('no-error').removeClass('hide');
                    }
                    
                },
                errors: function(err) {
                    console.log(err);
                    obj.prop('disabled', false).removeAttr('disabled');
                    $('form[name=custom_registration_form] .show-errors').text('Sorry! something went wrong').removeClass('no-error').removeClass('hide');

                }
            });
        }

    });


});