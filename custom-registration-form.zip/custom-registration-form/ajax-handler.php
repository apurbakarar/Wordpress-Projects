<?php

if(isset($_REQUEST) && !empty($_REQUEST) && isset($_REQUEST['name'])) {

	$path = preg_replace('/wp-content(?!.*wp-content).*/', '', __DIR__);
	
	include($path . 'wp-load.php');
	global $wpdb;

	// CREATE TABLE IF NOT EXISTS
	$charset_collate = $wpdb->get_charset_collate();
	$table_name = $wpdb->prefix . 'registrations';

	$sql = "CREATE TABLE IF NOT EXISTS $table_name (
			id INT(11) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
			name VARCHAR(100) NOT NULL,
			email VARCHAR(100) NOT NULL,
			mobile VARCHAR(100) NOT NULL,
			created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
			updated_at TIMESTAMP NULL
			
	) $charset_collate;";

	require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
	dbDelta( $sql );
	
	
	$insertData = [
		'name'	=>	$_REQUEST['name'],
		'email'	=>	$_REQUEST['email'],
		'mobile'	=>	$_REQUEST['mobile'],
	];
	
	$isInserted = $wpdb->insert($wpdb->prefix . 'registrations', $insertData);
	if($isInserted) {
		echo 1;
	}

}

?>



