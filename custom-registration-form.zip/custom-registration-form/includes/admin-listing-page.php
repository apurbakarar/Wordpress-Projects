<?php

if(! class_exists(ABSPATH . 'WP_List_Table')) {
	require_once(ABSPATH . 'wp-admin/includes/class-wp-list-table.php');
}


class CRF_custom_plugins extends WP_List_Table {


	public function prepare_items() {

		$this->items = $this->CRF_listing_data();
		$columns = $this->get_columns();
		$hidden_columns = $this->get_hidden_columns();

		$this->_column_headers = [$columns, $hidden_columns];

	}

	public function CRF_listing_data() {
		global $wpdb;

		$usersData = [];

		echo '<h2> Customer Registrations </h2>';

		$tableName = $wpdb->prefix . 'registrations';
		$sql = 'SELECT id, name, email, mobile FROM ' . $tableName;
		$showData = $wpdb->get_results($sql, ARRAY_A);
		if($showData) {
			foreach($showData as $details) {
				$usersData[] = [
					'id'		=>	$details['id'],
					'name'		=>	$details['name'],
					'email'		=>	$details['email'],
					'mobile'	=>	$details['mobile'],
				];
			}
		}
		 
		return $usersData ;
	}

	public function get_columns() {

		$data = [
			'id' => __('ID', CRF_TEXT_DOMAIN),
			'name' => __('Name', CRF_TEXT_DOMAIN),
			'email' => __('Email', CRF_TEXT_DOMAIN),
			'mobile' => __('Mobile', CRF_TEXT_DOMAIN),
		];

		return $data;

	}

	public function get_hidden_columns() {

		$data = [];

		return $data;

	}

	public function column_default( $item, $column_name ) {

		switch ($column_name) {
			case 'id':
			case 'name':
			case 'email':
			case 'mobile':
				return $item[$column_name];
				break;
			
			default:
				return 'No data found';
				break;
		}
	}




}

$newObj = new CRF_custom_plugins();
$newObj->prepare_items();
$newObj->display();

?>



